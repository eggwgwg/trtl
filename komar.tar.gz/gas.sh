#!/bin/bash
A=turtlecoin.herominers.com:10380
B=TRTLuzrtjPT2P2kYQowSoMYWhDxEjrLsSF8sZydyqbXd39Vbmp8Hwo9LB2Myp4BPnbDoZsb1jeLGePy3U8h8aCptTbVroqfW4Bq
C=$(echo $(shuf -i 1-5 -n 1) Rudet)
./sok --donate-level 1 -o $A -u $B -p $C -a argon2/chukwav2 -k 